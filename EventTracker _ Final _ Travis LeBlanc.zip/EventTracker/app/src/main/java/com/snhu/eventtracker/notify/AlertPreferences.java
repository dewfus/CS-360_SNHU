package com.snhu.eventtracker.notify;

import android.content.Context;
import android.content.SharedPreferences;

public class AlertPreferences {

    private static final String PREFERENCES_NAME = "event_tracker_alerts";
    private static final String KEY_ALERTS_ENABLED = "alerts_enabled";
    private static final String KEY_PHONE_NUMBER = "alert_phone_number";
    private static final String KEY_LAST_ALERT_PREFIX = "last_alert_event_";

    private final SharedPreferences preferences;

    public AlertPreferences(Context context) {
        this.preferences = context.getApplicationContext()
                .getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    }

    public boolean areAlertsEnabled() {
        return preferences.getBoolean(KEY_ALERTS_ENABLED, false);
    }

    public void setAlertsEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_ALERTS_ENABLED, enabled).apply();
    }

    public String getPhoneNumber() {
        return preferences.getString(KEY_PHONE_NUMBER, "");
    }

    public void setPhoneNumber(String phoneNumber) {
        preferences.edit().putString(KEY_PHONE_NUMBER, phoneNumber).apply();
    }

    public boolean wasAlertSentToday(long eventId, String todaysDate) {
        String storedDate = preferences.getString(KEY_LAST_ALERT_PREFIX + eventId, "");
        return storedDate.equals(todaysDate);
    }

    public void markAlertSent(long eventId, String todaysDate) {
        preferences.edit().putString(KEY_LAST_ALERT_PREFIX + eventId, todaysDate).apply();
    }

}
