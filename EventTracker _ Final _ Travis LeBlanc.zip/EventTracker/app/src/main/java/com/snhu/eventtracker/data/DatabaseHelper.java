package com.snhu.eventtracker.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "event_tracker.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "event_id";
    public static final String COLUMN_EVENT_NAME = "event_name";
    public static final String COLUMN_EVENT_DATE = "event_date";
    public static final String COLUMN_EVENT_TIME = "event_time";
    public static final String COLUMN_EVENT_OWNER = "owner_id";

    private static DatabaseHelper instance;

    private DatabaseHelper(Context context) {
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context);
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " ("
                        + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, "
                        + COLUMN_PASSWORD + " TEXT NOT NULL)";

        String createEventsTable =
                "CREATE TABLE " + TABLE_EVENTS + " ("
                        + COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + COLUMN_EVENT_NAME + " TEXT NOT NULL, "
                        + COLUMN_EVENT_DATE + " TEXT NOT NULL, "
                        + COLUMN_EVENT_TIME + " TEXT, "
                        + COLUMN_EVENT_OWNER + " INTEGER NOT NULL, "
                        + "FOREIGN KEY (" + COLUMN_EVENT_OWNER + ") REFERENCES "
                        + TABLE_USERS + "(" + COLUMN_USER_ID + ") ON DELETE CASCADE)";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // The app ships at version 1, so a simple rebuild is sufficient here.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Foreign keys are off by default in SQLite and must be enabled per connection.
        db.setForeignKeyConstraintsEnabled(true);
    }

}
