package com.snhu.eventtracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.snhu.eventtracker.data.Event;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    public interface EventActionListener {
        void onEventClicked(Event event);

        void onDeleteClicked(Event event);
    }

    private static final SimpleDateFormat STORAGE_DATE_FORMAT =
            new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private static final SimpleDateFormat DISPLAY_DATE_FORMAT =
            new SimpleDateFormat("MMM d, yyyy", Locale.US);

    private final List<Event> events = new ArrayList<>();
    private final EventActionListener actionListener;

    public EventAdapter(EventActionListener actionListener) {
        this.actionListener = actionListener;
    }

    public void setEvents(List<Event> updatedEvents) {
        events.clear();
        events.addAll(updatedEvents);
        notifyDataSetChanged();
    }

    public int getEventCount() {
        return events.size();
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        holder.bind(events.get(position));
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    private static String formatDateForDisplay(String storedDate) {
        try {
            Date parsedDate = STORAGE_DATE_FORMAT.parse(storedDate);
            return parsedDate == null ? storedDate : DISPLAY_DATE_FORMAT.format(parsedDate);
        } catch (ParseException exception) {
            return storedDate;
        }
    }

    class EventViewHolder extends RecyclerView.ViewHolder {

        private final TextView textEventName;
        private final TextView textEventDate;
        private final TextView textEventTime;
        private final View buttonDeleteEvent;

        EventViewHolder(@NonNull View itemView) {
            super(itemView);
            textEventName = itemView.findViewById(R.id.textEventName);
            textEventDate = itemView.findViewById(R.id.textEventDate);
            textEventTime = itemView.findViewById(R.id.textEventTime);
            buttonDeleteEvent = itemView.findViewById(R.id.buttonDeleteEvent);
        }

        void bind(Event event) {
            textEventName.setText(event.getEventName());
            textEventDate.setText(formatDateForDisplay(event.getEventDate()));

            // Time is optional, so the row is hidden rather than left blank.
            if (event.getEventTime() == null || event.getEventTime().isEmpty()) {
                textEventTime.setVisibility(View.GONE);
            } else {
                textEventTime.setVisibility(View.VISIBLE);
                textEventTime.setText(event.getEventTime());
            }

            itemView.setOnClickListener(view -> actionListener.onEventClicked(event));
            buttonDeleteEvent.setOnClickListener(view -> actionListener.onDeleteClicked(event));
        }
    }

}
