package com.snhu.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.snhu.eventtracker.data.UserRepository;



public class LoginActivity extends AppCompatActivity {

    private static final int MINIMUM_PASSWORD_LENGTH = 4;
    private TextInputLayout layoutUsername;
    private TextInputLayout layoutPassword;
    private TextInputEditText editUsername;
    private TextInputEditText editPassword;
    private UserRepository userRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        layoutUsername = findViewById(R.id.layoutUsername);
        layoutPassword = findViewById(R.id.layoutPassword);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        MaterialButton buttonSignIn = findViewById(R.id.buttonSignIn);
        MaterialButton buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        userRepository = new UserRepository(this);

        buttonSignIn.setOnClickListener(view -> attemptSignIn());
        buttonCreateAccount.setOnClickListener(view -> attemptCreateAccount());
    }

    private void attemptSignIn() {
        String username = readUsername();
        String password = readPassword();

        if (!hasValidInput(username, password)) {
            return;
        }

        if (!userRepository.userExists(username)) {
            layoutUsername.setError(getString(R.string.login_error_no_account));
            return;
        }

        long userId = userRepository.validateLogin(username, password);
        if (userId == UserRepository.NO_USER) {
            layoutPassword.setError(getString(R.string.login_error_wrong_password));
            return;
        }

        openEventsScreen(userId);
    }

    private void attemptCreateAccount() {
        String username = readUsername();
        String password = readPassword();

        if (!hasValidInput(username, password)) {
            return;
        }

        if (userRepository.userExists(username)) {
            layoutUsername.setError(getString(R.string.login_error_username_taken));
            return;
        }

        long userId = userRepository.createUser(username, password);
        if (userId == UserRepository.NO_USER) {
            Toast.makeText(this, R.string.login_error_create_failed, Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, R.string.login_account_created, Toast.LENGTH_SHORT).show();
        openEventsScreen(userId);
    }

    private boolean hasValidInput(String username, String password) {
        layoutUsername.setError(null);
        layoutPassword.setError(null);

        if (TextUtils.isEmpty(username)) {
            layoutUsername.setError(getString(R.string.login_error_username_required));
            return false;
        }

        if (TextUtils.isEmpty(password)) {
            layoutPassword.setError(getString(R.string.login_error_password_required));
            return false;
        }

        if (password.length() < MINIMUM_PASSWORD_LENGTH) {
            layoutPassword.setError(getString(R.string.login_error_password_length));
            return false;
        }

        return true;
    }

    private String readUsername() {
        return editUsername.getText() == null ? "" : editUsername.getText().toString().trim();
    }

    private String readPassword() {
        return editPassword.getText() == null ? "" : editPassword.getText().toString();
    }

    private void openEventsScreen(long userId) {
        Intent intent = new Intent(this, EventsActivity.class);
        intent.putExtra(EventsActivity.EXTRA_USER_ID, userId);
        startActivity(intent);
        finish();
    }

}
