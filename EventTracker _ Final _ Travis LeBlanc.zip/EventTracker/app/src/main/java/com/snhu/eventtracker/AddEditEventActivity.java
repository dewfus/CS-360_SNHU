package com.snhu.eventtracker;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.snhu.eventtracker.data.Event;
import com.snhu.eventtracker.data.EventRepository;
import com.snhu.eventtracker.data.UserRepository;

import java.util.Calendar;
import java.util.Locale;

public class AddEditEventActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID = "com.snhu.eventtracker.EXTRA_USER_ID";
    public static final String EXTRA_EVENT_ID = "com.snhu.eventtracker.EXTRA_EVENT_ID";

    private TextInputLayout layoutEventName;
    private TextInputLayout layoutEventDate;
    private TextInputEditText editEventName;
    private TextInputEditText editEventDate;
    private TextInputEditText editEventTime;

    private EventRepository eventRepository;
    private Event existingEvent;

    private long currentUserId;
    private long currentEventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_event);

        currentUserId = getIntent().getLongExtra(EXTRA_USER_ID, UserRepository.NO_USER);
        currentEventId = getIntent().getLongExtra(EXTRA_EVENT_ID, Event.UNSAVED_ID);

        eventRepository = new EventRepository(this);

        layoutEventName = findViewById(R.id.layoutEventName);
        layoutEventDate = findViewById(R.id.layoutEventDate);
        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        MaterialButton buttonSaveEvent = findViewById(R.id.buttonSaveEvent);

        editEventDate.setOnClickListener(view -> showDatePicker());
        editEventTime.setOnClickListener(view -> showTimePicker());
        buttonSaveEvent.setOnClickListener(view -> saveEvent());

        if (currentEventId == Event.UNSAVED_ID) {
            setTitle(R.string.add_event_title_new);
        } else {
            setTitle(R.string.add_event_title_edit);
            loadExistingEvent();
        }
    }

    private void loadExistingEvent() {
        existingEvent = eventRepository.getEventById(currentEventId);

        if (existingEvent == null) {
            Toast.makeText(this, R.string.add_event_not_found, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        editEventName.setText(existingEvent.getEventName());
        editEventDate.setText(existingEvent.getEventDate());
        editEventTime.setText(existingEvent.getEventTime());
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        String currentDate = readText(editEventDate);

        if (currentDate.length() == 10) {
            String[] dateParts = currentDate.split("-");
            calendar.set(Integer.parseInt(dateParts[0]),
                    Integer.parseInt(dateParts[1]) - 1,
                    Integer.parseInt(dateParts[2]));
        }

        new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> editEventDate.setText(
                        String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth)),
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();

        new TimePickerDialog(this,
                (view, hourOfDay, minute) -> editEventTime.setText(
                        String.format(Locale.US, "%02d:%02d", hourOfDay, minute)),
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                DateFormat.is24HourFormat(this)).show();
    }

    private void saveEvent() {
        layoutEventName.setError(null);
        layoutEventDate.setError(null);

        String eventName = readText(editEventName);
        String eventDate = readText(editEventDate);
        String eventTime = readText(editEventTime);

        if (TextUtils.isEmpty(eventName)) {
            layoutEventName.setError(getString(R.string.add_event_error_name));
            return;
        }

        if (TextUtils.isEmpty(eventDate)) {
            layoutEventDate.setError(getString(R.string.add_event_error_date));
            return;
        }

        boolean saved;
        if (existingEvent == null) {
            Event newEvent = new Event(eventName, eventDate, eventTime, currentUserId);
            saved = eventRepository.addEvent(newEvent) != Event.UNSAVED_ID;
        } else {
            existingEvent.setEventName(eventName);
            existingEvent.setEventDate(eventDate);
            existingEvent.setEventTime(eventTime);
            saved = eventRepository.updateEvent(existingEvent);
        }

        if (!saved) {
            Toast.makeText(this, R.string.add_event_save_failed, Toast.LENGTH_SHORT).show();
            return;
        }

        setResult(RESULT_OK);
        finish();
    }

    private String readText(TextInputEditText editText) {
        return editText.getText() == null ? "" : editText.getText().toString().trim();
    }


}
