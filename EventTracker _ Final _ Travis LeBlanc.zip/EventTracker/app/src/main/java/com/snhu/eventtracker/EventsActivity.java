package com.snhu.eventtracker;

import com.google.android.material.appbar.MaterialToolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.snhu.eventtracker.data.Event;
import com.snhu.eventtracker.data.EventRepository;
import com.snhu.eventtracker.data.UserRepository;
import com.snhu.eventtracker.notify.EventAlertManager;

import java.util.List;

public class  EventsActivity extends AppCompatActivity implements EventAdapter.EventActionListener {

    public static final String EXTRA_USER_ID = "com.snhu.eventtracker.EXTRA_USER_ID";

    private static final int GRID_COLUMN_COUNT = 2;

    private RecyclerView recyclerEvents;
    private TextView textEmptyState;
    private EventAdapter eventAdapter;
    private EventRepository eventRepository;

    private long currentUserId;
    private EventAlertManager alertManager;

    private final ActivityResultLauncher<Intent> addEditLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK) {
                            refreshEvents();
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        MaterialToolbar toolbarEvents = findViewById(R.id.toolbarEvents);
        setSupportActionBar(toolbarEvents);

        currentUserId = getIntent().getLongExtra(EXTRA_USER_ID, UserRepository.NO_USER);

        if (currentUserId == UserRepository.NO_USER) {
            Toast.makeText(this, R.string.events_session_expired, Toast.LENGTH_SHORT).show();
            returnToLogin();
            return;
        }

        eventRepository = new EventRepository(this);

        alertManager = new EventAlertManager(this);

        recyclerEvents = findViewById(R.id.recyclerEvents);
        textEmptyState = findViewById(R.id.textEmptyState);
        FloatingActionButton fabAddEvent = findViewById(R.id.fabAddEvent);

        eventAdapter = new EventAdapter(this);
        recyclerEvents.setLayoutManager(new GridLayoutManager(this, GRID_COLUMN_COUNT));
        recyclerEvents.setAdapter(eventAdapter);

        fabAddEvent.setOnClickListener(view -> openAddEditScreen(Event.UNSAVED_ID));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (eventRepository != null) {
            refreshEvents();
        }
    }

    private void refreshEvents() {
        List<Event> events = eventRepository.getEventsForUser(currentUserId);
        eventAdapter.setEvents(events);
        updateEmptyState();
        alertManager.sendAlertsForToday(currentUserId);
    }

    private void updateEmptyState() {
        boolean isEmpty = eventAdapter.getEventCount() == 0;
        textEmptyState.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        recyclerEvents.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onEventClicked(Event event) {
        openAddEditScreen(event.getEventId());
    }

    @Override
    public void onDeleteClicked(Event event) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.events_delete_title)
                .setMessage(getString(R.string.events_delete_message, event.getEventName()))
                .setPositiveButton(R.string.events_delete, (dialog, which) -> deleteEvent(event))
                .setNegativeButton(R.string.events_cancel, null)
                .show();
    }

    private void deleteEvent(Event event) {
        if (eventRepository.deleteEvent(event.getEventId())) {
            Toast.makeText(this, R.string.events_deleted, Toast.LENGTH_SHORT).show();
            refreshEvents();
        } else {
            Toast.makeText(this, R.string.events_delete_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void openAddEditScreen(long eventId) {
        Intent intent = new Intent(this, AddEditEventActivity.class);
        intent.putExtra(AddEditEventActivity.EXTRA_USER_ID, currentUserId);
        intent.putExtra(AddEditEventActivity.EXTRA_EVENT_ID, eventId);
        addEditLauncher.launch(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.menu_events, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_notifications) {
            startActivity(new Intent(this, SmsPermissionActivity.class));
            return true;
        }

        if (itemId == R.id.action_sign_out) {
            returnToLogin();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void returnToLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

}
