package com.snhu.eventtracker.notify;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.snhu.eventtracker.R;
import com.snhu.eventtracker.data.Event;
import com.snhu.eventtracker.data.EventRepository;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EventAlertManager {

    private static final String LOG_TAG = "EventAlertManager";
    private static final String CHANNEL_ID = "event_reminders";
    private static final int NOTIFICATION_ID_BASE = 2000;

    private static final SimpleDateFormat STORAGE_DATE_FORMAT =
            new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    private final Context context;
    private final EventRepository eventRepository;
    private final AlertPreferences alertPreferences;

    public EventAlertManager(Context context) {
        this.context = context.getApplicationContext();
        this.eventRepository = new EventRepository(this.context);
        this.alertPreferences = new AlertPreferences(this.context);
        createNotificationChannel();
    }

    public int sendAlertsForToday(long userId) {
        if (!alertPreferences.areAlertsEnabled()) {
            return 0;
        }

        String todaysDate = STORAGE_DATE_FORMAT.format(new Date());
        List<Event> todaysEvents = eventRepository.getEventsOnDate(todaysDate);

        int alertsSent = 0;
        for (Event event : todaysEvents) {
            if (event.getOwnerId() != userId) {
                continue;
            }

            if (alertPreferences.wasAlertSentToday(event.getEventId(), todaysDate)) {
                continue;
            }

            if (deliverAlert(event)) {
                alertPreferences.markAlertSent(event.getEventId(), todaysDate);
                alertsSent++;
            }
        }

        return alertsSent;
    }

    private boolean deliverAlert(Event event) {
        String message = buildAlertMessage(event);

        if (hasSmsPermission() && !alertPreferences.getPhoneNumber().isEmpty()) {
            return sendSmsAlert(message);
        }

        return sendNotificationAlert(event, message);
    }

    private String buildAlertMessage(Event event) {
        if (event.getEventTime() == null || event.getEventTime().isEmpty()) {
            return context.getString(R.string.alert_message_all_day, event.getEventName());
        }
        return context.getString(R.string.alert_message_timed,
                event.getEventName(), event.getEventTime());
    }

    private boolean sendSmsAlert(String message) {
        try {
            SmsManager smsManager = getSmsManager();
            String phoneNumber = alertPreferences.getPhoneNumber();

            smsManager.sendMultipartTextMessage(
                    phoneNumber,
                    null,
                    smsManager.divideMessage(message),
                    null,
                    null);
            return true;
        } catch (Exception exception) {
            Log.e(LOG_TAG, "Unable to send the SMS alert", exception);
            return false;
        }
    }

    private SmsManager getSmsManager() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return context.getSystemService(SmsManager.class);
        }
        return SmsManager.getDefault();
    }

    private boolean sendNotificationAlert(Event event, String message) {
        if (!hasNotificationPermission()) {
            return false;
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(context.getString(R.string.alert_notification_title))
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        try {
            NotificationManagerCompat.from(context)
                    .notify(NOTIFICATION_ID_BASE + (int) event.getEventId(), builder.build());
            return true;
        } catch (SecurityException exception) {
            Log.e(LOG_TAG, "Unable to post the notification alert", exception);
            return false;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.alert_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription(context.getString(R.string.alert_channel_description));

        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.createNotificationChannel(channel);
        }
    }

    public boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public boolean hasNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return true;
        }
        return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

}
