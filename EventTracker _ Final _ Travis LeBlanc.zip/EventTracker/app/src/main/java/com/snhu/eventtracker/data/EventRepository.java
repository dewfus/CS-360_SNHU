package com.snhu.eventtracker.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class EventRepository {

    private final DatabaseHelper databaseHelper;

    public EventRepository(Context context) {
        this.databaseHelper = DatabaseHelper.getInstance(context);
    }

    public long addEvent(Event event) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        long newRowId = db.insert(DatabaseHelper.TABLE_EVENTS, null, toContentValues(event));

        if (newRowId != -1) {
            event.setEventId(newRowId);
            return newRowId;
        }
        return Event.UNSAVED_ID;
    }

    public List<Event> getEventsForUser(long ownerId) {
        List<Event> events = new ArrayList<>();

        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_EVENTS,
                null,
                DatabaseHelper.COLUMN_EVENT_OWNER + " = ?",
                new String[]{String.valueOf(ownerId)},
                null, null,
                DatabaseHelper.COLUMN_EVENT_DATE + " ASC");

        while (cursor.moveToNext()) {
            events.add(fromCursor(cursor));
        }
        cursor.close();
        return events;
    }

    public Event getEventById(long eventId) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_EVENTS,
                null,
                DatabaseHelper.COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(eventId)},
                null, null, null);

        Event event = null;
        if (cursor.moveToFirst()) {
            event = fromCursor(cursor);
        }
        cursor.close();
        return event;
    }

    public List<Event> getEventsOnDate(String eventDate) {
        List<Event> events = new ArrayList<>();

        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_EVENTS,
                null,
                DatabaseHelper.COLUMN_EVENT_DATE + " = ?",
                new String[]{eventDate},
                null, null,
                DatabaseHelper.COLUMN_EVENT_TIME + " ASC");

        while (cursor.moveToNext()) {
            events.add(fromCursor(cursor));
        }
        cursor.close();
        return events;
    }

    public boolean updateEvent(Event event) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int rowsAffected = db.update(
                DatabaseHelper.TABLE_EVENTS,
                toContentValues(event),
                DatabaseHelper.COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(event.getEventId())});

        return rowsAffected == 1;
    }

    public boolean deleteEvent(long eventId) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int rowsAffected = db.delete(
                DatabaseHelper.TABLE_EVENTS,
                DatabaseHelper.COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(eventId)});

        return rowsAffected == 1;
    }

    private ContentValues toContentValues(Event event) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_EVENT_NAME, event.getEventName());
        values.put(DatabaseHelper.COLUMN_EVENT_DATE, event.getEventDate());
        values.put(DatabaseHelper.COLUMN_EVENT_TIME, event.getEventTime());
        values.put(DatabaseHelper.COLUMN_EVENT_OWNER, event.getOwnerId());
        return values;
    }

    /** Builds an Event object from the row the cursor is currently pointing at. */
    private Event fromCursor(Cursor cursor) {
        return new Event(
                cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME)),
                cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_OWNER)));
    }

}
