package com.snhu.eventtracker.data;

public class Event {

    public static final long UNSAVED_ID = -1;

    private long eventId;
    private String eventName;
    private String eventDate;
    private String eventTime;
    private long ownerId;

    public Event(String eventName, String eventDate, String eventTime, long ownerId) {
        this(UNSAVED_ID, eventName, eventDate, eventTime, ownerId);
    }

    public Event(long eventId, String eventName, String eventDate, String eventTime, long ownerId) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.ownerId = ownerId;
    }

    public long getEventId() {
        return eventId;
    }

    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }

}
