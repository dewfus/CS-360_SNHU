package com.snhu.eventtracker;

import android.Manifest;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.snhu.eventtracker.notify.AlertPreferences;
import com.snhu.eventtracker.notify.EventAlertManager;

public class SmsPermissionActivity extends AppCompatActivity {

    private CompoundButton switchAlerts;
    private TextInputLayout layoutPhoneNumber;
    private TextInputEditText editPhoneNumber;
    private TextView textPermissionStatus;

    private AlertPreferences alertPreferences;
    private EventAlertManager alertManager;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            Toast.makeText(this, R.string.sms_granted_toast,
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, R.string.sms_denied_toast,
                                    Toast.LENGTH_LONG).show();
                            requestNotificationPermissionIfNeeded();
                        }
                        updatePermissionStatus();
                    });

    private final ActivityResultLauncher<String> notificationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    isGranted -> updatePermissionStatus());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
        setTitle(R.string.sms_title);

        alertPreferences = new AlertPreferences(this);
        alertManager = new EventAlertManager(this);

        switchAlerts = findViewById(R.id.switchAlerts);
        layoutPhoneNumber = findViewById(R.id.layoutPhoneNumber);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        MaterialButton buttonSaveSettings = findViewById(R.id.buttonSaveSettings);

        switchAlerts.setChecked(alertPreferences.areAlertsEnabled());
        editPhoneNumber.setText(alertPreferences.getPhoneNumber());

        switchAlerts.setOnCheckedChangeListener((button, isChecked) -> {
            if (isChecked) {
                requestAlertPermissions();
            }
            updatePermissionStatus();
        });

        buttonSaveSettings.setOnClickListener(view -> saveSettings());
        updatePermissionStatus();
    }

    private void requestAlertPermissions() {
        if (alertManager.hasSmsPermission()) {
            requestNotificationPermissionIfNeeded();
            return;
        }
        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (!alertManager.hasNotificationPermission()) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

    private void updatePermissionStatus() {
        boolean alertsOn = switchAlerts.isChecked();
        boolean smsAllowed = alertManager.hasSmsPermission();

        layoutPhoneNumber.setEnabled(alertsOn && smsAllowed);

        if (!alertsOn) {
            textPermissionStatus.setText(R.string.sms_status_off);
        } else if (smsAllowed) {
            textPermissionStatus.setText(R.string.sms_status_text_message);
        } else {
            textPermissionStatus.setText(R.string.sms_status_notification);
        }
    }

    private void saveSettings() {
        layoutPhoneNumber.setError(null);

        boolean alertsOn = switchAlerts.isChecked();
        String phoneNumber = editPhoneNumber.getText() == null
                ? "" : editPhoneNumber.getText().toString().trim();

        if (alertsOn && alertManager.hasSmsPermission() && TextUtils.isEmpty(phoneNumber)) {
            layoutPhoneNumber.setError(getString(R.string.sms_error_phone_required));
            return;
        }

        alertPreferences.setAlertsEnabled(alertsOn);
        alertPreferences.setPhoneNumber(phoneNumber);

        Toast.makeText(this, R.string.sms_saved_toast, Toast.LENGTH_SHORT).show();
        finish();
    }

}
